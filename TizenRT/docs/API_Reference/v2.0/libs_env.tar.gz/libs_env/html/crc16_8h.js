var crc16_8h =
[
    [ "EXTERN", "group___c_r_c___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "crc16", "group___c_r_c___k_e_r_n_e_l.html#ga586edd30d6d0e4516b3c5b94a8496713", null ],
    [ "crc16part", "group___c_r_c___k_e_r_n_e_l.html#ga8421ea4873bcc56153238eba93fec980", null ]
];