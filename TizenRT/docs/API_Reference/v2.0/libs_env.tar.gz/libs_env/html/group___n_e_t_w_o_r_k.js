var group___n_e_t_w_o_r_k =
[
    [ "Socket", "group___s_o_c_k_e_t.html", "group___s_o_c_k_e_t" ],
    [ "DHCP", "group___d_h_c_p.html", "group___d_h_c_p" ]
];