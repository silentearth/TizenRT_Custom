var group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l =
[
    [ "semholder_s", "structsemholder__s.html", [
      [ "counts", "structsemholder__s.html#ad5daea048a26df74654c14cf74f5e649", null ],
      [ "flink", "structsemholder__s.html#a096d555130ebfe80e358ea6ed9f73040", null ],
      [ "htcb", "structsemholder__s.html#a5e905b458a3ececa661606dee4d66900", null ]
    ] ],
    [ "sem_s", "structsem__s.html", [
      [ "flags", "structsem__s.html#aa2585d779da0ab21273a8d92de9a0ebe", null ],
      [ "hhead", "structsem__s.html#aea49aff8c6d1dc7c6b3c5d06dc861446", null ],
      [ "semcount", "structsem__s.html#a79a6d245cb1295cccd31fa97f81b0e24", null ]
    ] ],
    [ "SEM_INITIALIZER", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga03a85057a48f3994ae3cfd34f236c634", null ],
    [ "sem_destroy", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga256a9ac860cdf1e243be5bfd9939e077", null ],
    [ "sem_getvalue", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga73f28b253e7e48e0cb5f53b2320b044c", null ],
    [ "sem_init", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga41b26c90117772865047ff8a9449dffd", null ],
    [ "sem_post", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga88d920a68734cf85bdb713617b4e4982", null ],
    [ "sem_timedwait", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga05b485dfe748f4999641e64a938d9c45", null ],
    [ "sem_trywait", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga77807eafac6f94c7b8618c9a655699ef", null ],
    [ "sem_wait", "group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html#ga981826c83322f1248d544a2e6449290b", null ]
];