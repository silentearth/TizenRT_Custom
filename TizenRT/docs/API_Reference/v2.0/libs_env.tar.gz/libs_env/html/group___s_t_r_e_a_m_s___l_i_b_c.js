var group___s_t_r_e_a_m_s___l_i_b_c =
[
    [ "lib_instream_s", "structlib__instream__s.html", [
      [ "get", "structlib__instream__s.html#ac1e61219acdbdf0f832f5cdc17bd14bc", null ],
      [ "nget", "structlib__instream__s.html#a5569072b97423681526c03c1d2c60fc5", null ]
    ] ],
    [ "lib_outstream_s", "structlib__outstream__s.html", [
      [ "nput", "structlib__outstream__s.html#af55bde58b75130c4be39abdafaca70e5", null ],
      [ "put", "structlib__outstream__s.html#abad7053496488be482fafc150f72267d", null ]
    ] ],
    [ "lib_sistream_s", "structlib__sistream__s.html", [
      [ "get", "structlib__sistream__s.html#a2404695066db4dabb754b034b894bd89", null ],
      [ "nget", "structlib__sistream__s.html#a5569072b97423681526c03c1d2c60fc5", null ],
      [ "seek", "structlib__sistream__s.html#a477da61effd4ea0669b0771ff5cfdad2", null ]
    ] ],
    [ "lib_sostream_s", "structlib__sostream__s.html", [
      [ "nput", "structlib__sostream__s.html#af55bde58b75130c4be39abdafaca70e5", null ],
      [ "put", "structlib__sostream__s.html#ae591451af6d8ff93729325f9ed991b0f", null ],
      [ "seek", "structlib__sostream__s.html#a771a3324416b1feb60a9ecedd44b36b3", null ]
    ] ],
    [ "lib_meminstream_s", "structlib__meminstream__s.html", [
      [ "buffer", "structlib__meminstream__s.html#a0f128ed7d962f6124bdc02b892953910", null ],
      [ "buflen", "structlib__meminstream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
      [ "public", "structlib__meminstream__s.html#a287caaec902c6f6e83a40416c4dc2c1d", null ]
    ] ],
    [ "lib_memoutstream_s", "structlib__memoutstream__s.html", [
      [ "buffer", "structlib__memoutstream__s.html#adc743ae92a4a3617eba532437879e25d", null ],
      [ "buflen", "structlib__memoutstream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
      [ "public", "structlib__memoutstream__s.html#aeeaaca22c06f00191d452e4bb1878464", null ]
    ] ],
    [ "lib_memsistream_s", "structlib__memsistream__s.html", [
      [ "buffer", "structlib__memsistream__s.html#a0f128ed7d962f6124bdc02b892953910", null ],
      [ "buflen", "structlib__memsistream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
      [ "offset", "structlib__memsistream__s.html#aadb6d6eb83e646653a1402032e45dcab", null ],
      [ "public", "structlib__memsistream__s.html#a0955f45b98cbb9b51a440a1b954165bb", null ]
    ] ],
    [ "lib_memsostream_s", "structlib__memsostream__s.html", [
      [ "buffer", "structlib__memsostream__s.html#adc743ae92a4a3617eba532437879e25d", null ],
      [ "buflen", "structlib__memsostream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
      [ "offset", "structlib__memsostream__s.html#aadb6d6eb83e646653a1402032e45dcab", null ],
      [ "public", "structlib__memsostream__s.html#ae14ea3567e9a05f3b08eaa1bec665dae", null ]
    ] ],
    [ "lib_stdinstream_s", "structlib__stdinstream__s.html", [
      [ "public", "structlib__stdinstream__s.html#a287caaec902c6f6e83a40416c4dc2c1d", null ],
      [ "stream", "structlib__stdinstream__s.html#ae64992450acc585492de9edbca5fc826", null ]
    ] ],
    [ "lib_stdoutstream_s", "structlib__stdoutstream__s.html", [
      [ "public", "structlib__stdoutstream__s.html#aeeaaca22c06f00191d452e4bb1878464", null ],
      [ "stream", "structlib__stdoutstream__s.html#ae64992450acc585492de9edbca5fc826", null ]
    ] ],
    [ "lib_stdsistream_s", "structlib__stdsistream__s.html", [
      [ "public", "structlib__stdsistream__s.html#a0955f45b98cbb9b51a440a1b954165bb", null ],
      [ "stream", "structlib__stdsistream__s.html#ae64992450acc585492de9edbca5fc826", null ]
    ] ],
    [ "lib_stdsostream_s", "structlib__stdsostream__s.html", [
      [ "public", "structlib__stdsostream__s.html#ae14ea3567e9a05f3b08eaa1bec665dae", null ],
      [ "stream", "structlib__stdsostream__s.html#ae64992450acc585492de9edbca5fc826", null ]
    ] ],
    [ "lib_rawinstream_s", "structlib__rawinstream__s.html", [
      [ "fd", "structlib__rawinstream__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "public", "structlib__rawinstream__s.html#a287caaec902c6f6e83a40416c4dc2c1d", null ]
    ] ],
    [ "lib_rawoutstream_s", "structlib__rawoutstream__s.html", [
      [ "fd", "structlib__rawoutstream__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "public", "structlib__rawoutstream__s.html#aeeaaca22c06f00191d452e4bb1878464", null ]
    ] ],
    [ "lib_rawsistream_s", "structlib__rawsistream__s.html", [
      [ "fd", "structlib__rawsistream__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "public", "structlib__rawsistream__s.html#a0955f45b98cbb9b51a440a1b954165bb", null ]
    ] ],
    [ "lib_rawsostream_s", "structlib__rawsostream__s.html", [
      [ "fd", "structlib__rawsostream__s.html#a6f8059414f0228f0256115e024eeed4b", null ],
      [ "public", "structlib__rawsostream__s.html#ae14ea3567e9a05f3b08eaa1bec665dae", null ]
    ] ],
    [ "lib_lowoutstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gad5889133a63a922aa4f44a4d70d080a2", null ],
    [ "lib_meminstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gac4d4129cd7ffd259a945d098afb0d21c", null ],
    [ "lib_memoutstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga687b2cd361490d8984a9d58e247003ca", null ],
    [ "lib_memsistream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga04904c00ae73ac133d14bb6a6eb5cbe2", null ],
    [ "lib_memsostream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gad872973c6c955f084ac3e532dc59ae0f", null ],
    [ "lib_nullinstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga9c4a84468c04d84f00206881b991aa09", null ],
    [ "lib_nulloutstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gaca44f8ebc9d07e4061267d6fbb6ce134", null ],
    [ "lib_rawinstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga498ee1a461aecc82bba64b4947e7d6c7", null ],
    [ "lib_rawoutstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga4d9c2ff324cdabee905180e12429879a", null ],
    [ "lib_rawsistream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gae57c15c5e46fb78ce6a2274067af67af", null ],
    [ "lib_rawsostream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gac6c06b44d3515c2085850b0e8e1f9603", null ],
    [ "lib_stdinstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga32d2fa37d59099189494b52cddb0e124", null ],
    [ "lib_stdoutstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gaa2aeb8894119a09920318d489c421309", null ],
    [ "lib_stdsistream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga00ee8c4db4e2d52a9357fa67cdbf2e08", null ],
    [ "lib_stdsostream", "group___s_t_r_e_a_m_s___l_i_b_c.html#ga4a6d0d21e5717d9cd91baf4463ccde86", null ],
    [ "lib_zeroinstream", "group___s_t_r_e_a_m_s___l_i_b_c.html#gaa2797ee44cd19841d7b612c9be95de2b", null ]
];