var group___t_e_r_m_i_o_s___k_e_r_n_e_l =
[
    [ "termios", "structtermios.html", [
      [ "c_cc", "structtermios.html#a06ea1504c051c8b60c9e5d04b63877dd", null ],
      [ "c_cflag", "structtermios.html#ac6409888277d696c033f0068b33d5acc", null ],
      [ "c_iflag", "structtermios.html#a3e416181096da14aacc3a5aaa3138d3e", null ],
      [ "c_lflag", "structtermios.html#ad03044b6d30bc840e24751ea465651af", null ],
      [ "c_oflag", "structtermios.html#a615efcbde1bbfd1f2c28b3a62bd05add", null ],
      [ "c_speed", "structtermios.html#a9b14ff83a882d409ce372efd707f76f4", null ]
    ] ],
    [ "tcgetattr", "group___t_e_r_m_i_o_s___k_e_r_n_e_l.html#ga8f7bb62f5d696c1651c0164abc396cac", null ],
    [ "tcsetattr", "group___t_e_r_m_i_o_s___k_e_r_n_e_l.html#gaae01531d89ed0098e5b9fc80fc29d6bb", null ]
];