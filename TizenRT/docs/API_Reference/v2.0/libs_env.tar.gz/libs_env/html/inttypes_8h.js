var inttypes_8h =
[
    [ "EXTERN", "group___i_n_t_t_y_p_e_s___l_i_b_c.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "imaxabs", "group___i_n_t_t_y_p_e_s___l_i_b_c.html#gad9e8a565a34b6981f500d88773ec7bcd", null ],
    [ "imaxdiv", "group___i_n_t_t_y_p_e_s___l_i_b_c.html#gabdaff0aa6f40596b90b84a7ad63d2299", null ],
    [ "strtoimax", "group___i_n_t_t_y_p_e_s___l_i_b_c.html#ga7ad86ad36fda90ae868b12ab384e60ac", null ],
    [ "strtoumax", "group___i_n_t_t_y_p_e_s___l_i_b_c.html#gab65cfb4941a47d041e50a636c9efb626", null ]
];