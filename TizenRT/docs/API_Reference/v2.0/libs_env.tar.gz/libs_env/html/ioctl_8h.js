var ioctl_8h =
[
    [ "EXTERN", "group___i_o_c_t_l___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "ioctl", "group___i_o_c_t_l___k_e_r_n_e_l.html#ga6762739f1ceb8c62fa4f26304a76fb36", null ]
];