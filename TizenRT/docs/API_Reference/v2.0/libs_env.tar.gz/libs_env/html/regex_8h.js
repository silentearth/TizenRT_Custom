var regex_8h =
[
    [ "EXTERN", "group___r_e_g_e_x___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "match", "group___r_e_g_e_x___k_e_r_n_e_l.html#ga9bc4ff2fac85bd5c1708e53da5b48048", null ]
];