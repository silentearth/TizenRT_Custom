var searchData=
[
  ['kernel_2flibc',['KERNEL/LIBC',['../group___k_e_r_n_e_l.html',1,'']]],
  ['key_5fdata',['key_data',['../structpthread__tcb__s.html#a5059bcf4634e93bf3c77f3765e9a2cbb',1,'pthread_tcb_s']]],
  ['key_5finuse',['KEY_INUSE',['../tinyara_2sched_8h.html#aa536ae8b918a8fd297a667d0d30c7b58',1,'sched.h']]],
  ['key_5fnot_5finuse',['KEY_NOT_INUSE',['../tinyara_2sched_8h.html#a12586a7a577a507350baea9ed4ab2ede',1,'sched.h']]],
  ['kill',['kill',['../group___s_i_g_n_a_l___k_e_r_n_e_l.html#ga4539db972bcf3dd8c8b429af0dc3789d',1,'signal.h']]]
];
