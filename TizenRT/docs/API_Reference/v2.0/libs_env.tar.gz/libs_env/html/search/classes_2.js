var searchData=
[
  ['dirent',['dirent',['../structdirent.html',1,'']]],
  ['div_5fs',['div_s',['../structdiv__s.html',1,'']]],
  ['dq_5fentry_5fs',['dq_entry_s',['../structdq__entry__s.html',1,'']]],
  ['dq_5fqueue_5fs',['dq_queue_s',['../structdq__queue__s.html',1,'']]],
  ['dspace_5fs',['dspace_s',['../structdspace__s.html',1,'']]]
];
