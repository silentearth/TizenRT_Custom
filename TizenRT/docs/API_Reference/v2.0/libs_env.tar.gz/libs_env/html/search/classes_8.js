var searchData=
[
  ['netent',['netent',['../structnetent.html',1,'']]],
  ['netif',['netif',['../structnetif.html',1,'']]]
];
