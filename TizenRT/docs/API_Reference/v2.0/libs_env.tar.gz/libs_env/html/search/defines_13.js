var searchData=
[
  ['xcase',['XCASE',['../termios_8h.html#aa9a106fb947d86f7e0bdb534cc0426e5',1,'termios.h']]]
];
