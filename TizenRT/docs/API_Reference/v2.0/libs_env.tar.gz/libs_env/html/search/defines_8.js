var searchData=
[
  ['key_5finuse',['KEY_INUSE',['../tinyara_2sched_8h.html#aa536ae8b918a8fd297a667d0d30c7b58',1,'sched.h']]],
  ['key_5fnot_5finuse',['KEY_NOT_INUSE',['../tinyara_2sched_8h.html#a12586a7a577a507350baea9ed4ab2ede',1,'sched.h']]]
];
