var searchData=
[
  ['last_5fblocked_5fstate',['LAST_BLOCKED_STATE',['../tinyara_2sched_8h.html#ac2214abf5fe38b0febd0ee36e20c7539',1,'sched.h']]],
  ['last_5fready_5fto_5frun_5fstate',['LAST_READY_TO_RUN_STATE',['../tinyara_2sched_8h.html#a80120ffed98a1b7b731391b5f53875a5',1,'sched.h']]]
];
