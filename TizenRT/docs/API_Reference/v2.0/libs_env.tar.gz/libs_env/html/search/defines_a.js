var searchData=
[
  ['max_5flock_5fcount',['MAX_LOCK_COUNT',['../tinyara_2sched_8h.html#ab8bff8b66b8a8bb0c5bc97d59383a7ea',1,'sched.h']]],
  ['mb_5fcur_5fmax',['MB_CUR_MAX',['../stdlib_8h.html#a5455b7a60d7e3087ec55dfe37a088bd1',1,'stdlib.h']]]
];
