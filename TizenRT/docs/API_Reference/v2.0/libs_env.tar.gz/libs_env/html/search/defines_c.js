var searchData=
[
  ['ocrnl',['OCRNL',['../termios_8h.html#adc345d36b46c6ccdd079c9ecc3fc1296',1,'termios.h']]],
  ['ofill',['OFILL',['../termios_8h.html#ae6ebfbba412b33b84de07c35f12b2d7f',1,'termios.h']]],
  ['olcuc',['OLCUC',['../termios_8h.html#a2ed0011eaf721d107946bf06f1824b36',1,'termios.h']]],
  ['onlcr',['ONLCR',['../termios_8h.html#a957436bc6db0a0d49b081dc9b4c98ef2',1,'termios.h']]],
  ['onlret',['ONLRET',['../termios_8h.html#a8fd17e0aa25ab2abd07477442ba1928e',1,'termios.h']]],
  ['onocr',['ONOCR',['../termios_8h.html#aab452deaf5d1b993c3b0ff2d3e408577',1,'termios.h']]],
  ['opost',['OPOST',['../termios_8h.html#a0aad4afe9e202fff8ced3485bc835bb1',1,'termios.h']]]
];
