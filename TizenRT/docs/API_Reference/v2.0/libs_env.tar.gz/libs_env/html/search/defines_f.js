var searchData=
[
  ['semholder_5finitializer',['SEMHOLDER_INITIALIZER',['../semaphore_8h.html#a2cf61eec374a9897175edffb46d0c415',1,'semaphore.h']]],
  ['srandom',['srandom',['../stdlib_8h.html#a94059a462b4c33a59641c8573f3fb623',1,'stdlib.h']]]
];
