var searchData=
[
  ['fota_5fpartition_5fid_5fs',['fota_partition_id_s',['../fota__hal_8h.html#a20da9d8257e0569095eb8b54022d216e',1,'fota_hal.h']]],
  ['fotahal_5freturn_5fe',['fotahal_return_e',['../fota__hal_8h.html#ac5dc52c79dfc917e89b7ae0bc845c29a',1,'fota_hal.h']]]
];
