var searchData=
[
  ['idtype_5fe',['idtype_e',['../group___s_c_h_e_d___k_e_r_n_e_l.html#gab94fc59592a010bb7982bd96c2e96fd6',1,'wait.h']]]
];
