var searchData=
[
  ['p_5fall',['P_ALL',['../group___s_c_h_e_d___k_e_r_n_e_l.html#ggab94fc59592a010bb7982bd96c2e96fd6a3e3e77552a242f89c892494ef1596758',1,'wait.h']]],
  ['p_5fgid',['P_GID',['../group___s_c_h_e_d___k_e_r_n_e_l.html#ggab94fc59592a010bb7982bd96c2e96fd6a5e6d20ec791dfabaa43a3af0880b13ec',1,'wait.h']]],
  ['p_5fpid',['P_PID',['../group___s_c_h_e_d___k_e_r_n_e_l.html#ggab94fc59592a010bb7982bd96c2e96fd6a670c56bdd326fb6de6112e15dd6c020e',1,'wait.h']]]
];
