var searchData=
[
  ['tstate_5ftask_5finactive',['TSTATE_TASK_INACTIVE',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353a6cd13c70f8e09cf00a7d099a96e5e941',1,'sched.h']]],
  ['tstate_5ftask_5finvalid',['TSTATE_TASK_INVALID',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353a999f34013301c67a1898e701937c21c4',1,'sched.h']]],
  ['tstate_5ftask_5fpending',['TSTATE_TASK_PENDING',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353a182255dcf1544b1c5f0fc9220f4c0789',1,'sched.h']]],
  ['tstate_5ftask_5freadytorun',['TSTATE_TASK_READYTORUN',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353a1fbc3eba6ffcbc2334833276af23c5c6',1,'sched.h']]],
  ['tstate_5ftask_5frunning',['TSTATE_TASK_RUNNING',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353a081628e43124658cb1041ea74ff2be9e',1,'sched.h']]],
  ['tstate_5fwait_5fmqnotempty',['TSTATE_WAIT_MQNOTEMPTY',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353ae8854b90d2eb0a5aa3efe551a107a815',1,'sched.h']]],
  ['tstate_5fwait_5fmqnotfull',['TSTATE_WAIT_MQNOTFULL',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353a2ef228cb36f92971ee05695d16c43a85',1,'sched.h']]],
  ['tstate_5fwait_5fsem',['TSTATE_WAIT_SEM',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353aa40b226cbe3dd0e3de3672d503208cc3',1,'sched.h']]],
  ['tstate_5fwait_5fsig',['TSTATE_WAIT_SIG',['../tinyara_2sched_8h.html#afc82e1a9d5e68ce0c111e0b26eae9353aaf6bd732bf5ace381547b3ee846d37cb',1,'sched.h']]]
];
