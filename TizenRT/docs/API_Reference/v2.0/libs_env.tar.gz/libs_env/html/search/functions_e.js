var searchData=
[
  ['on_5fexit',['on_exit',['../group___s_t_d_l_i_b___l_i_b_c.html#gad490080c199fabe42d03f10cb05580d9',1,'stdlib.h']]],
  ['open',['open',['../group___f_c_n_t_l___k_e_r_n_e_l.html#ga62e93eb794fed24c0f46c6acda6ea510',1,'fcntl.h']]],
  ['opendir',['opendir',['../group___d_i_r_e_n_t___k_e_r_n_e_l.html#gaee1d70d65ae374aa3c857edf2298a715',1,'dirent.h']]]
];
