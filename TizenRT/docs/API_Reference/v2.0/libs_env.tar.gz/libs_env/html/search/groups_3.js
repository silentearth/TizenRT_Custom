var searchData=
[
  ['errno',['ERRNO',['../group___e_r_r_n_o___k_e_r_n_e_l.html',1,'']]]
];
