var searchData=
[
  ['kernel_2flibc',['KERNEL/LIBC',['../group___k_e_r_n_e_l.html',1,'']]]
];
