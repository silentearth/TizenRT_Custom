var searchData=
[
  ['poll',['POLL',['../group___p_o_l_l___k_e_r_n_e_l.html',1,'']]],
  ['pthread',['PTHREAD',['../group___p_t_h_r_e_a_d___k_e_r_n_e_l.html',1,'']]]
];
