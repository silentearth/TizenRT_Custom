var searchData=
[
  ['sched',['SCHED',['../group___s_c_h_e_d___k_e_r_n_e_l.html',1,'']]],
  ['security',['SECURITY',['../group___s_e_c_u_r_i_t_y.html',1,'']]],
  ['select',['SELECT',['../group___s_e_l_e_c_t___k_e_r_n_e_l.html',1,'']]],
  ['semaphore',['SEMAPHORE',['../group___s_e_m_a_p_h_o_r_e___k_e_r_n_e_l.html',1,'']]],
  ['signal',['SIGNAL',['../group___s_i_g_n_a_l___k_e_r_n_e_l.html',1,'']]],
  ['socket',['Socket',['../group___s_o_c_k_e_t.html',1,'']]],
  ['stat',['STAT',['../group___s_t_a_t___k_e_r_n_e_l.html',1,'']]],
  ['stdio',['STDIO',['../group___s_t_d_i_o___l_i_b_c.html',1,'']]],
  ['stdlib',['STDLIB',['../group___s_t_d_l_i_b___l_i_b_c.html',1,'']]],
  ['streams',['STREAMS',['../group___s_t_r_e_a_m_s___l_i_b_c.html',1,'']]],
  ['string',['STRING',['../group___s_t_r_i_n_g___l_i_b_c.html',1,'']]],
  ['syslog',['SYSLOG',['../group___s_y_s_l_o_g___l_i_b_c.html',1,'']]]
];
