var searchData=
[
  ['_5fsa_5fhandler_5ft',['_sa_handler_t',['../group___s_i_g_n_a_l___k_e_r_n_e_l.html#ga3799c5c8781121acf9c1782700121f32',1,'signal.h']]],
  ['_5fsa_5fsigaction_5ft',['_sa_sigaction_t',['../group___s_i_g_n_a_l___k_e_r_n_e_l.html#ga93078ad3bb2d0811aa1579518c5d4639',1,'signal.h']]]
];
