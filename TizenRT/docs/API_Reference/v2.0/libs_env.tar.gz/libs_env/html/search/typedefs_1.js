var searchData=
[
  ['atexitfunc_5ft',['atexitfunc_t',['../tinyara_2sched_8h.html#a8826b9c767486ef0059c417f1872d179',1,'sched.h']]]
];
