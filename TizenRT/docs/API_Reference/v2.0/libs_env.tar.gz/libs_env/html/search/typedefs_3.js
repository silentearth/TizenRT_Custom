var searchData=
[
  ['cc_5ft',['cc_t',['../termios_8h.html#a6fea89760aff47450c2f213cc748e803',1,'termios.h']]],
  ['clockid_5ft',['clockid_t',['../group___t_i_m_e___k_e_r_n_e_l.html#ga130a5d727cde7241e5c77f87550c2851',1,'time.h']]]
];
