var searchData=
[
  ['dir',['DIR',['../group___d_i_r_e_n_t___k_e_r_n_e_l.html#ga6808d95339147c6e29523463181854cc',1,'dirent.h']]],
  ['div_5ft',['div_t',['../stdlib_8h.html#a451bf8e942393ea6d2b6a0592f9862d9',1,'stdlib.h']]],
  ['dq_5fentry_5ft',['dq_entry_t',['../group___q_u_e_u_e___l_i_b_c.html#gac3f015c0d8692f3acd1cced028e4c59d',1,'queue.h']]],
  ['dq_5fqueue_5ft',['dq_queue_t',['../group___q_u_e_u_e___l_i_b_c.html#ga24c26e3f971325b6324ef83fb6ac479d',1,'queue.h']]]
];
