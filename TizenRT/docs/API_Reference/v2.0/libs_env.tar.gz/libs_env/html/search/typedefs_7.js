var searchData=
[
  ['idtype_5ft',['idtype_t',['../wait_8h.html#a677237daaa63daf345b531572ab40cb4',1,'wait.h']]],
  ['inihandle',['INIHANDLE',['../inifile_8h.html#ab629efe1def925ec982e41a5fe07f7e6',1,'inifile.h']]]
];
