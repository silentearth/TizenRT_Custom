var searchData=
[
  ['mqd_5ft',['mqd_t',['../group___m_q_u_e_u_e___k_e_r_n_e_l.html#ga7903b465c5f2702f94428208a2707ddf',1,'mqueue.h']]]
];
