var searchData=
[
  ['netif_5finit_5ffn',['netif_init_fn',['../group___d_h_c_p.html#ga2b02a78a8769925ff8e4f83d34e5e1f5',1,'netif.h']]],
  ['netif_5finput_5ffn',['netif_input_fn',['../group___d_h_c_p.html#gab2302b1b64ac7b95f24c6bab754a575e',1,'netif.h']]],
  ['netif_5flinkoutput_5ffn',['netif_linkoutput_fn',['../group___d_h_c_p.html#gab75e9d808bc1b788bea84213e6a111ed',1,'netif.h']]],
  ['netif_5fstatus_5fcallback_5ffn',['netif_status_callback_fn',['../group___d_h_c_p.html#ga447d0a7e7c6e2396557c287b8b8c9436',1,'netif.h']]],
  ['nfds_5ft',['nfds_t',['../group___p_o_l_l___k_e_r_n_e_l.html#gaa49b6bf041fda66eda01c0170243c271',1,'poll.h']]]
];
