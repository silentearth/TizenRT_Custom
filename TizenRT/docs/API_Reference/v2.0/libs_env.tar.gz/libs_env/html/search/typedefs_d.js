var searchData=
[
  ['sched_5fforeach_5ft',['sched_foreach_t',['../tinyara_2sched_8h.html#a12b3c4f4913d16bb11d10746bb7ca42f',1,'sched.h']]],
  ['sem_5ft',['sem_t',['../semaphore_8h.html#a46ffaa053d8dd29535b4795ef0cd442f',1,'semaphore.h']]],
  ['siginfo_5ft',['siginfo_t',['../group___s_i_g_n_a_l___k_e_r_n_e_l.html#ga7f8ded3c2dce4eb81ce41694c03a32e4',1,'signal.h']]],
  ['sigset_5ft',['sigset_t',['../group___s_i_g_n_a_l___k_e_r_n_e_l.html#ga7fba2a7c692afae7caa4564f8f82169d',1,'signal.h']]],
  ['speed_5ft',['speed_t',['../termios_8h.html#a2382e7ab9e04d2ee3e5a2db0d7053ef6',1,'termios.h']]],
  ['sq_5fentry_5ft',['sq_entry_t',['../group___q_u_e_u_e___l_i_b_c.html#ga17d0d32195f92dcda6268743c956230c',1,'queue.h']]],
  ['sq_5fqueue_5ft',['sq_queue_t',['../group___q_u_e_u_e___l_i_b_c.html#gaadc0b747571c18376b0941f690b70043',1,'queue.h']]],
  ['start_5ft',['start_t',['../tinyara_2sched_8h.html#a41971c1e9571255023e3606c2e7cb5a6',1,'sched.h']]],
  ['starthook_5ft',['starthook_t',['../tinyara_2sched_8h.html#afa280f9fff63b9963d03c2dcc527b236',1,'sched.h']]]
];
