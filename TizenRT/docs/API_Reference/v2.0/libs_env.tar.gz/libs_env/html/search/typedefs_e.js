var searchData=
[
  ['task_5fcallback',['TASK_CALLBACK',['../builtin_8h.html#a30c2eed8c3c01e9b4018d549460ca3d3',1,'builtin.h']]],
  ['tcflag_5ft',['tcflag_t',['../termios_8h.html#a568e6d6409568ed4b3a4495da01ee56d',1,'termios.h']]],
  ['time_5ft',['time_t',['../group___t_i_m_e___k_e_r_n_e_l.html#ga3346b04b0420b32ccf6b706551b70762',1,'time.h']]],
  ['timer_5ft',['timer_t',['../group___t_i_m_e___k_e_r_n_e_l.html#ga06339249c719efff419b61ad9aa6ddcd',1,'time.h']]],
  ['tstate_5ft',['tstate_t',['../tinyara_2sched_8h.html#aa443fd18f8511bacb7ab3c3b60bbc965',1,'sched.h']]]
];
