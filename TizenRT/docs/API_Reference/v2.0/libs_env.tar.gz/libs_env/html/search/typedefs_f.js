var searchData=
[
  ['ub16_5ft',['ub16_t',['../group___f_i_x_e_d_m_a_t_h___l_i_b_c.html#gaae12f6b2882c27281fe234552b768d26',1,'fixedmath.h']]],
  ['ub32_5ft',['ub32_t',['../group___f_i_x_e_d_m_a_t_h___l_i_b_c.html#gaf588c5e14e2236670a8604db28b69b1a',1,'fixedmath.h']]],
  ['ub8_5ft',['ub8_t',['../group___f_i_x_e_d_m_a_t_h___l_i_b_c.html#ga309ea48f8b727036393ba5b26e9bd35a',1,'fixedmath.h']]]
];
