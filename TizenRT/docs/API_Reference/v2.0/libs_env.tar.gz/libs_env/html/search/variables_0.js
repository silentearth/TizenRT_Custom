var searchData=
[
  ['_5fsa_5fhandler',['_sa_handler',['../structsigaction.html#a0a2bf7f3ade56385c9459e9039eac0c3',1,'sigaction']]],
  ['_5fsa_5fsigaction',['_sa_sigaction',['../structsigaction.html#af3712e4d852e9ae60215a61e2a6c8cd8',1,'sigaction']]]
];
