var searchData=
[
  ['address',['address',['../structpthread__region__s.html#ab96816d317aa5196e2ef198d9a8d621b',1,'pthread_region_s']]],
  ['adj_5fstack_5fptr',['adj_stack_ptr',['../structtcb__s.html#a1083d195aca193b7547e83b6ee67544e',1,'tcb_s']]],
  ['adj_5fstack_5fsize',['adj_stack_size',['../structtcb__s.html#aefe317ab9207054a1a86a0ea6ca0796a',1,'tcb_s']]],
  ['aliases',['aliases',['../structservent__data.html#ab952ad03440652f6cb01467436e2f661',1,'servent_data']]],
  ['arena',['arena',['../structmallinfo.html#a7202a6840820bbf924bd78fef95420f8',1,'mallinfo']]],
  ['arg',['arg',['../structpthread__tcb__s.html#a94d7347cbe17653e285d0a0c695c33bc',1,'pthread_tcb_s']]],
  ['argv',['argv',['../structtask__tcb__s.html#aa5189ec135933f3a558ca38bb8685cbc',1,'task_tcb_s']]],
  ['attributes',['attributes',['../structpthread__region__s.html#a5b07acd04f2485df951064cfb9177ce3',1,'pthread_region_s']]]
];
