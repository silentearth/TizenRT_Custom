var searchData=
[
  ['quot',['quot',['../structimaxdiv__t.html#a49341c3e52bace7a25816fde6c57fc06',1,'imaxdiv_t::quot()'],['../structdiv__s.html#a2065955c249938f83ebf6bc6c07b4200',1,'div_s::quot()'],['../structldiv__s.html#ac4000ffefcdd50a3cd0dc04fabfcce34',1,'ldiv_s::quot()'],['../structlldiv__s.html#ac4000ffefcdd50a3cd0dc04fabfcce34',1,'lldiv_s::quot()']]]
];
