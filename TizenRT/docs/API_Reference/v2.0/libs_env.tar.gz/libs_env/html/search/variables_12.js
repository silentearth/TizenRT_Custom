var searchData=
[
  ['region',['region',['../structpthread__attr__s.html#a8729d9c1806f50e849d795ec4f2af4c1',1,'pthread_attr_s::region()'],['../structdspace__s.html#ab51bd19de5152811de3eee7d6d8fb42c',1,'dspace_s::region()']]],
  ['rem',['rem',['../structimaxdiv__t.html#a39127037b16df9952a3220b657254141',1,'imaxdiv_t::rem()'],['../structdiv__s.html#a1ba4c6426d29538ceed6a0db9b4e1df6',1,'div_s::rem()'],['../structldiv__s.html#a7c04b7afc95e3cc4480a634f3073ba8a',1,'ldiv_s::rem()'],['../structlldiv__s.html#a7c04b7afc95e3cc4480a634f3073ba8a',1,'lldiv_s::rem()']]],
  ['revents',['revents',['../structpollfd.html#a847a1e5a35870f186846a4c724108879',1,'pollfd']]]
];
