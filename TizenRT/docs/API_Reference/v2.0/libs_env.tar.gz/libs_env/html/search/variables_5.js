var searchData=
[
  ['entry',['entry',['../structtcb__s.html#a92e0ebbaff3b113d6b2ab51c4a9c92d4',1,'tcb_s::entry()'],['../structbuiltin__info__s.html#a6134381ff001a881e03bf01f1c054a3a',1,'builtin_info_s::entry()']]],
  ['event_5ftype',['event_type',['../structtrace__packet.html#a31642948667912627b6722a938e8b3d2',1,'trace_packet']]],
  ['events',['events',['../structpollfd.html#a442f5a81fde427aec032b11f0448e992',1,'pollfd']]],
  ['exectype',['exectype',['../structbuiltin__info__s.html#a5f2b35290f05bdae2b0ab952af21c76b',1,'builtin_info_s']]]
];
