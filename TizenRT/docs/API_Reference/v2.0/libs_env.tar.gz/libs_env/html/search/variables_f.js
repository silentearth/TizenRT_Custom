var searchData=
[
  ['offset',['offset',['../structlib__memsistream__s.html#aadb6d6eb83e646653a1402032e45dcab',1,'lib_memsistream_s::offset()'],['../structlib__memsostream__s.html#aadb6d6eb83e646653a1402032e45dcab',1,'lib_memsostream_s::offset()']]],
  ['optarg',['optarg',['../group___u_n_i_s_t_d___k_e_r_n_e_l.html#gad3039a88b6ace3852aac0b76809192d6',1,'unistd.h']]],
  ['optind',['optind',['../group___u_n_i_s_t_d___k_e_r_n_e_l.html#gaa1eb060dbf5ab33fc567bd22f62c6052',1,'unistd.h']]],
  ['optopt',['optopt',['../group___u_n_i_s_t_d___k_e_r_n_e_l.html#gafbf14aa88c2d1d630f801da8fedd12cc',1,'unistd.h']]],
  ['ordblks',['ordblks',['../structmallinfo.html#a6307b6068dec061900d98e9a5d7ef5c6',1,'mallinfo']]]
];
