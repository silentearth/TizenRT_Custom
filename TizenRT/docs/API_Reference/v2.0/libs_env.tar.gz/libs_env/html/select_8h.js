var select_8h =
[
    [ "__SELECT_NDESCRIPTORS", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#gabb0b398fe7219d4e4bd34a4c6a078d70", null ],
    [ "__SELECT_NUINT32", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#ga5f59be7e03eaba73a0371fe41e078e12", null ],
    [ "EXTERN", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "FD_CLR", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#gad914a2f676490d92b1f509bb6e93b459", null ],
    [ "FD_ISSET", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#ga0d02a891286ee61c9e7ecd291c96567f", null ],
    [ "FD_SET", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#gac9a6234e30e3cb64542eca6dab921a93", null ],
    [ "FD_ZERO", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#ga13ea72abe5159156453a8a957d8880cb", null ],
    [ "fd_set", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#gaf0ed703bf1724b9af3e4d30d0cc932af", null ],
    [ "select", "group___s_e_l_e_c_t___k_e_r_n_e_l.html#ga5cbefc529ae6fe4bc7b8b4259831c1b4", null ]
];