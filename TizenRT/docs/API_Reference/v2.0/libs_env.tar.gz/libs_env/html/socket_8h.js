var socket_8h =
[
    [ "EXTERN", "group___s_o_c_k_e_t.html#ga77366c1bd428629dc898e188bfd182a3", null ],
    [ "accept", "group___s_o_c_k_e_t.html#ga7937a1ce0c865387d092f8440f7ef5bd", null ],
    [ "bind", "group___s_o_c_k_e_t.html#gab67314000187827423e1f2179a9f9975", null ],
    [ "connect", "group___s_o_c_k_e_t.html#ga63b7ac20cd6881fdd24e718702011981", null ],
    [ "getpeername", "group___s_o_c_k_e_t.html#ga4f016ffafb303902b981988fdc675940", null ],
    [ "getsockname", "group___s_o_c_k_e_t.html#gab8b489c45d5b9b0f94dbe578361f1271", null ],
    [ "getsockopt", "group___s_o_c_k_e_t.html#gacd28da109b0b420c2b8e35c6e71a5737", null ],
    [ "listen", "group___s_o_c_k_e_t.html#ga5989c21d05cb17caba26cef496a7beea", null ],
    [ "recv", "group___s_o_c_k_e_t.html#ga893583dc49862175155ccc71b213c0b8", null ],
    [ "recvfrom", "group___s_o_c_k_e_t.html#gae37bffe1ee7e68d9a7ca8b6fb0f47a07", null ],
    [ "recvmsg", "group___s_o_c_k_e_t.html#ga839d5b323cc725649953be13649e2407", null ],
    [ "send", "group___s_o_c_k_e_t.html#ga079072f3fc982c55fe82c6525ff9e2e1", null ],
    [ "sendmsg", "group___s_o_c_k_e_t.html#ga97ff69134a8c7d749a5eb02fa4f644e0", null ],
    [ "sendto", "group___s_o_c_k_e_t.html#ga89d6efe0d8080ce09ac1e562a99116c6", null ],
    [ "setsockopt", "group___s_o_c_k_e_t.html#ga6e1a92cc461dffa60f625b2261e20d22", null ],
    [ "shutdown", "group___s_o_c_k_e_t.html#ga402425b8e1ceab40ac38a949babcf1aa", null ],
    [ "socket", "group___s_o_c_k_e_t.html#gaf4e0711877c45a41168ac677b0670ccd", null ]
];