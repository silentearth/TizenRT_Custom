var structdirent =
[
    [ "d_name", "structdirent.html#a28ed4d956394cb6d3311f13cf281b888", null ],
    [ "d_type", "structdirent.html#a7d6049fc80878c22522b5bdb8e907014", null ]
];