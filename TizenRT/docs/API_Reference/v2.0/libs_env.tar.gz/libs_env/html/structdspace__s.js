var structdspace__s =
[
    [ "crefs", "structdspace__s.html#ab1b5877517439382ef953b4c6578143f", null ],
    [ "region", "structdspace__s.html#ab51bd19de5152811de3eee7d6d8fb42c", null ]
];