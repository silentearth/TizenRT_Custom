var structimaxdiv__t =
[
    [ "quot", "structimaxdiv__t.html#a49341c3e52bace7a25816fde6c57fc06", null ],
    [ "rem", "structimaxdiv__t.html#a39127037b16df9952a3220b657254141", null ]
];