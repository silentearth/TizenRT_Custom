var structlib__memsostream__s =
[
    [ "buffer", "structlib__memsostream__s.html#adc743ae92a4a3617eba532437879e25d", null ],
    [ "buflen", "structlib__memsostream__s.html#ad6994903b3c19997ffcfdccb4431d308", null ],
    [ "offset", "structlib__memsostream__s.html#aadb6d6eb83e646653a1402032e45dcab", null ],
    [ "public", "structlib__memsostream__s.html#ae14ea3567e9a05f3b08eaa1bec665dae", null ]
];