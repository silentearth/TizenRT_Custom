var structlib__stdinstream__s =
[
    [ "public", "structlib__stdinstream__s.html#a287caaec902c6f6e83a40416c4dc2c1d", null ],
    [ "stream", "structlib__stdinstream__s.html#ae64992450acc585492de9edbca5fc826", null ]
];