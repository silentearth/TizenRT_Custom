var structpollfd =
[
    [ "events", "structpollfd.html#a442f5a81fde427aec032b11f0448e992", null ],
    [ "fd", "structpollfd.html#a6f8059414f0228f0256115e024eeed4b", null ],
    [ "priv", "structpollfd.html#a20dbbd0eba0038e1c9b4c169b3becbd0", null ],
    [ "revents", "structpollfd.html#a847a1e5a35870f186846a4c724108879", null ],
    [ "sem", "structpollfd.html#a5c905d8d60d9e4d58e9a4a5ec07ec44c", null ]
];