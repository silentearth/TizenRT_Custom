var structprotoent =
[
    [ "p_aliases", "structprotoent.html#a47ecb00361c88e87d5966ab8cf75fa77", null ],
    [ "p_name", "structprotoent.html#a8b952e1d81b21605efa33da3c9ee5eab", null ],
    [ "p_proto", "structprotoent.html#a2df7b976a723d7d9a15f18c355131b04", null ]
];