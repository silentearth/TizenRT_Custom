var structpthread__attr__s =
[
    [ "inheritsched", "structpthread__attr__s.html#a542d158b0863b8afefdf7be925d10af7", null ],
    [ "policy", "structpthread__attr__s.html#a6b22d59f607ab98e910257c4e97a343a", null ],
    [ "priority", "structpthread__attr__s.html#a33b1d1ca7832408ce0c459ac8d8716b8", null ],
    [ "region", "structpthread__attr__s.html#a8729d9c1806f50e849d795ec4f2af4c1", null ],
    [ "stacksize", "structpthread__attr__s.html#ac6351740c6b6c1ea66b5723e19ff8ca2", null ]
];