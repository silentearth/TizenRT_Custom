var structpthread__barrier__s =
[
    [ "count", "structpthread__barrier__s.html#a16ff2d8e15ade4948398b0aeb80124a8", null ],
    [ "sem", "structpthread__barrier__s.html#a57e5f989454185402d689672f370a749", null ]
];