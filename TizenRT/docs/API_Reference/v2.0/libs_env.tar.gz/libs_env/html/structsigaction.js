var structsigaction =
[
    [ "_sa_handler", "structsigaction.html#a0a2bf7f3ade56385c9459e9039eac0c3", null ],
    [ "_sa_sigaction", "structsigaction.html#af3712e4d852e9ae60215a61e2a6c8cd8", null ],
    [ "sa_flags", "structsigaction.html#aa2f4cbbe861afa8d03d2d979a9f82119", null ],
    [ "sa_mask", "structsigaction.html#a5010ed0e8a055170e1ba016c22c77fdc", null ],
    [ "sa_u", "structsigaction.html#aa0a3882ecab1648678fc5d5b71493785", null ]
];