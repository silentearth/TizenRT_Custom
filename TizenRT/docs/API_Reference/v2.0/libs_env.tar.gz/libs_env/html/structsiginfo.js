var structsiginfo =
[
    [ "si_code", "structsiginfo.html#a2c84cf4cdaf791e53642e633f281e5ad", null ],
    [ "si_pid", "structsiginfo.html#a3b6606b209cb01c0c68e4df3acffc152", null ],
    [ "si_signo", "structsiginfo.html#a2108967017e8fded779163fb8275c0d5", null ],
    [ "si_status", "structsiginfo.html#af913a7543240c501353b0bc4a9f58c6c", null ],
    [ "si_value", "structsiginfo.html#a10a81fa9ef7c0f8151911d0557477000", null ]
];