var tinyara_2time_8h =
[
    [ "EPOCH_YEAR", "tinyara_2time_8h.html#aa0e47af385cda59b56c1ba71dee795d8", null ],
    [ "EXTERN", "tinyara_2time_8h.html#a77366c1bd428629dc898e188bfd182a3", null ],
    [ "clock_calendar2utc", "group___t_i_m_e___k_e_r_n_e_l.html#ga878ff017cb55743793db635435eb6764", null ],
    [ "clock_daysbeforemonth", "group___t_i_m_e___k_e_r_n_e_l.html#ga8d7982cb4392358a96e6314f6f521f1e", null ],
    [ "clock_isleapyear", "group___t_i_m_e___k_e_r_n_e_l.html#ga6108f90bb93e923602d084153805b3a3", null ]
];