var wait_8h =
[
    [ "EXTERN", "wait_8h.html#a77366c1bd428629dc898e188bfd182a3", null ],
    [ "WCONTINUED", "wait_8h.html#afcc090a70f53d677b748f4b1a4b896e6", null ],
    [ "WEXITED", "wait_8h.html#a004990811e046790b928dbc7787ecfaa", null ],
    [ "WEXITSTATUS", "wait_8h.html#ac12790c67befecfcd8cc28bd53be2899", null ],
    [ "WIFCONTINUED", "wait_8h.html#ae5533b3213b8e81491aa4212ac8fc602", null ],
    [ "WIFEXITED", "wait_8h.html#af840540f1b7be5831f9dcca7ca2f656d", null ],
    [ "WIFSIGNALED", "wait_8h.html#ae67566e76143e34dbdb295cf00e8b275", null ],
    [ "WIFSTOPPED", "wait_8h.html#a1e2fc8f167ac004a82c6136ce723afed", null ],
    [ "WNOHANG", "wait_8h.html#afa288d86b242c3005425a9c0f1682544", null ],
    [ "WNOWAIT", "wait_8h.html#a68e8ee6dc7b0115ddc033d974792fa94", null ],
    [ "WSTOPPED", "wait_8h.html#a34c9a2f671a03d4523a4e7d9642f908f", null ],
    [ "WSTOPSIG", "wait_8h.html#a210adbf6be2c8ae5e7cad27b7d7eb846", null ],
    [ "WTERMSIG", "wait_8h.html#ae1ee738b884803f9df25133825025528", null ],
    [ "WUNTRACED", "wait_8h.html#aecac6945e3b08baa2602557c684d6bfe", null ],
    [ "idtype_t", "wait_8h.html#a677237daaa63daf345b531572ab40cb4", null ],
    [ "idtype_e", "group___s_c_h_e_d___k_e_r_n_e_l.html#gab94fc59592a010bb7982bd96c2e96fd6", [
      [ "P_PID", "group___s_c_h_e_d___k_e_r_n_e_l.html#ggab94fc59592a010bb7982bd96c2e96fd6a670c56bdd326fb6de6112e15dd6c020e", null ],
      [ "P_GID", "group___s_c_h_e_d___k_e_r_n_e_l.html#ggab94fc59592a010bb7982bd96c2e96fd6a5e6d20ec791dfabaa43a3af0880b13ec", null ],
      [ "P_ALL", "group___s_c_h_e_d___k_e_r_n_e_l.html#ggab94fc59592a010bb7982bd96c2e96fd6a3e3e77552a242f89c892494ef1596758", null ]
    ] ],
    [ "wait", "group___s_c_h_e_d___k_e_r_n_e_l.html#ga64679f9ed4ab9c9bca5d0b2a3b6900b6", null ],
    [ "waitid", "group___s_c_h_e_d___k_e_r_n_e_l.html#gae94c0a06f50645ca890be6eb15d8ed3d", null ],
    [ "waitpid", "group___s_c_h_e_d___k_e_r_n_e_l.html#ga0839a6e449e9a67aa65e878337bf849e", null ]
];